//
// Copyright(C) 1993-1996 Id Software, Inc.
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//     Main loop code.
//

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <emscripten.h>

#include "d_event.h"
#include "d_loop.h"
#include "d_ticcmd.h"
#include "debug.h"

#include "i_system.h"
#include "i_timer.h"
#include "i_video.h"

#include "m_argv.h"
#include "m_fixed.h"

#include "net_client.h"
#include "net_gui.h"
#include "net_io.h"
#include "net_loop.h"
#include "net_query.h"
#include "net_server.h"
#include "net_webxdc.h"
#include "z_zone.h"

uint32_t instanceUID;

// The complete set of data for a particular tic.

typedef struct {
    ticcmd_t cmds[NET_MAXPLAYERS];
    boolean ingame[NET_MAXPLAYERS];
} ticcmd_set_t;

// Maximum time that we wait in TryRunTics() for netgame data to be
// received before we fabricate missing tics and advance anyway.
// VectorDoom: we NEVER block the game loop. If remote tics are missing,
// we repeat the last known ticcmd and let the snapshot system correct drift.
#define MAX_NETGAME_STALL_TICS 2

// Send a state snapshot every N tics.
// 3 = every ~86ms (~12/s). Momentum extrapolation fills gaps smoothly.
// Lower = more bandwidth, higher = more reliance on extrapolation.
// At 140 msgs/s the gossip channel chokes on high-ping connections;
// 12/s * 3 packet types = ~36 msgs/s total — much healthier.
#define SNAPSHOT_INTERVAL 3

//
// gametic is the tic about to (or currently being) run
// maketic is the tic that hasn't had control made for it yet
// recvtic is the latest tic received from the server.
//
// a gametic cannot be run until ticcmds are received for it
// from all players.
//

static ticcmd_set_t ticdata[BACKUPTICS];

// The index of the next tic to be made (with a call to BuildTiccmd).

static int maketic;

// The number of complete tics received from the server so far.

static int recvtic;

// VectorDoom: true once we've received at least one real tic from the
// server. Fabrication is unsafe before this because game state (player
// mobjs, level data) may not be fully synchronized yet.
static boolean received_first_tic = false;

// The number of tics that have been run (using RunTic) so far.

int gametic;

// When set to true, a single tic is run each time TryRunTics() is called.
// This is used for -timedemo mode.

boolean singletics = false;

// Index of the local player.

static int localplayer;

// Used for original sync code.

static int skiptics = 0;

// Reduce the bandwidth needed by sampling game input less and transmitting
// less.  If ticdup is 2, sample half normal, 3 = one third normal, etc.

int ticdup;

// Amount to offset the timer for game sync.

fixed_t offsetms;

// Use new client syncronisation code

static boolean new_sync = true;

// Callback functions for loop code.

static loop_interface_t *loop_interface = NULL;

// Track whether we are the host (server) for health authority
static boolean is_host = false;

// Cached client flag — set once in D_InitNetGame, used in hot paths
// (defined in g_game.c, declared in doomstat.h)
extern boolean net_client_player;

// Current players in the multiplayer game.
// This is distinct from playeringame[] used by the game code, which may
// modify playeringame[] when playing back multiplayer demos.

static boolean local_playeringame[NET_MAXPLAYERS];

// Requested player class "sent" to the server on connect.
// If we are only doing a single player game then this needs to be remembered
// and saved in the game settings.

static int player_class;

// 35 fps clock adjusted by offsetms milliseconds

static int GetAdjustedTime(void)
{
    int time_ms;

    time_ms = I_GetTimeMS();

    if (new_sync) {
        // Use the adjustments from net_client.c only if we are
        // using the new sync mode.

        time_ms += (offsetms / FRACUNIT);
    }

    return (time_ms * TICRATE) / 1000;
}

static boolean BuildNewTic(void)
{
    int gameticdiv;
    ticcmd_t cmd;

    gameticdiv = gametic / ticdup;

    I_StartTic();
    loop_interface->ProcessEvents();

    // Always run the menu

    loop_interface->RunMenu();

    if (drone) {
        // In drone mode, do not generate any ticcmds.

        return false;
    }

    if (new_sync) {
        // If playing single player, do not allow tics to buffer
        // up very far

        if (!net_client_connected && maketic - gameticdiv > 2) return false;

        // Never go more than ~200ms ahead

        if (maketic - gameticdiv > 8) return false;
    }
    else {
        if (maketic - gameticdiv >= 5) return false;
    }

    // printf ("mk:%i ",maketic);
    memset(&cmd, 0, sizeof(ticcmd_t));
    loop_interface->BuildTiccmd(&cmd, maketic);

    if (net_client_connected) {
        NET_CL_SendTiccmd(&cmd, maketic);
    }

    ticdata[maketic % BACKUPTICS].cmds[localplayer] = cmd;
    ticdata[maketic % BACKUPTICS].ingame[localplayer] = true;

    ++maketic;

    return true;
}

//
// NetUpdate
// Builds ticcmds for console player,
// sends out a packet
//
int lasttime;

void NetUpdate(void)
{
    int nowtime;
    int newtics;
    int i;

    // If we are running with singletics (timing a demo), this
    // is all done separately.

    if (singletics) return;

    // Run network subsystems

    NET_CL_Run();
    NET_SV_Run();

    // check time
    nowtime = GetAdjustedTime() / ticdup;
    newtics = nowtime - lasttime;

    lasttime = nowtime;

    if (skiptics <= newtics) {
        newtics -= skiptics;
        skiptics = 0;
    }
    else {
        skiptics -= newtics;
        newtics = 0;
    }

    // build new ticcmds for console player

    for (i = 0; i < newtics; i++) {
        if (!BuildNewTic()) {
            break;
        }
    }
}

// VectorDoom: Host migration — promote this client to host.
// Called from PlayerQuitGame when the host (player 0) disconnects.
// Flips authority flags, starts server infrastructure, and tells JS
// to broadcast server beacons so new players can discover and join.
void D_PromoteToHost(void)
{
    extern boolean net_client_player;

    // 1. Flip game logic flags
    is_host = true;
    net_client_player = false;

    // 2. Start server infrastructure so new clients can connect
    if (!NET_SV_IsInitialized()) {
        NET_SV_Init();
        NET_SV_AddModule(&net_webxdc_module);
        NET_SV_AddModule(&net_loop_server_module);
    }
    // Set server to in-game state (not waiting for launch)
    NET_SV_SetState(2);  // SERVER_IN_GAME

    // 3. Tell JS layer to start broadcasting server beacons
    // New peers will discover us via the election protocol
    EM_ASM({
        if (globalThis._webxdcChannel) {
            // Broadcast server beacon immediately + every 5 seconds
            var startedAt = globalThis._appStartedAt || Date.now();
            var buf = new ArrayBuffer(16);
            var u8 = new Uint8Array(buf);
            u8[0] = 43; u8[1] = 43; u8[2] = 43; u8[3] = 43;
            var f64 = new Float64Array(buf, 8, 1);
            f64[0] = startedAt;
            try { globalThis._webxdcChannel.send(u8); } catch(e) {}
            setInterval(function() {
                try { globalThis._webxdcChannel.send(u8); } catch(e) {}
            }, 5000);
        }
        console.log("doom: host migration — now broadcasting server beacons");
    });

    printf("doom: host migration — promoted to host, server started\n");
}

static void D_Disconnected(void)
{
    // In drone mode, the game cannot continue once disconnected.

    if (drone) {
        I_Error("Disconnected from server in drone mode.");
    }

    // disconnected from server

    printf("doom: 9, disconnected from server\n");
}

//
// Invoked by the network engine when a complete set of ticcmds is
// available.
//

void D_ReceiveTic(ticcmd_t *ticcmds, boolean *players_mask)
{
    int i;

    // Disconnected from server?

    if (ticcmds == NULL && players_mask == NULL) {
        D_Disconnected();
        return;
    }

    for (i = 0; i < NET_MAXPLAYERS; ++i) {
        if (!drone && i == localplayer) {
            // This is us.  Don't overwrite it.
        }
        else {
            ticdata[recvtic % BACKUPTICS].cmds[i] = ticcmds[i];
            ticdata[recvtic % BACKUPTICS].ingame[i] = players_mask[i];
        }
    }

    // Also set local player's ingame flag (BuildNewTic only sets cmds)
    ticdata[recvtic % BACKUPTICS].ingame[localplayer] = true;

    received_first_tic = true;
    ++recvtic;
}

//
// Start game loop
//
// Called after the screen is set but before the game starts running.
//

void D_StartGameLoop(void) { lasttime = GetAdjustedTime() / ticdup; }

//
// Block until the game start message is received from the server.
//

static void BlockUntilStart(net_gamesettings_t *settings, netgame_startup_callback_t callback)
{
    while (!NET_CL_GetSettings(settings)) {
        NET_CL_Run();
        NET_SV_Run();

        if (!net_client_connected) {
            I_Error("Lost connection to server");
        }

        if (callback != NULL && !callback(net_client_wait_data.ready_players, net_client_wait_data.num_players)) {
            I_Error("Netgame startup aborted.");
        }

        I_Sleep(100);
    }
}

void D_StartNetGame(net_gamesettings_t *settings, netgame_startup_callback_t callback)
{
    int i;

    offsetms = 0;
    recvtic = 0;
    received_first_tic = false;

    settings->consoleplayer = 0;
    settings->num_players = 1;
    settings->start_tic = 0;
    settings->player_classes[0] = player_class;

    //!
    // @category net
    //
    // Use original network client sync code rather than the improved
    // sync code.
    //
    settings->new_sync = !M_ParmExists("-oldsync");

    //!
    // @category net
    // @arg <n>
    //
    // Send n extra tics in every packet as insurance against dropped
    // packets.
    //

    i = M_CheckParmWithArgs("-extratics", 1);

    if (i > 0)
        settings->extratics = atoi(myargv[i + 1]);
    else
        settings->extratics = 1;

    //!
    // @category net
    // @arg <n>
    //
    // Reduce the resolution of the game by a factor of n, reducing
    // the amount of network bandwidth needed.
    //

    i = M_CheckParmWithArgs("-dup", 1);

    if (i > 0)
        settings->ticdup = atoi(myargv[i + 1]);
    else
        settings->ticdup = 1;

    if (net_client_connected) {
        // Send our game settings and block until game start is received
        // from the server.

        NET_CL_StartGame(settings);
        BlockUntilStart(settings, callback);

        // Read the game settings that were received.
        NET_CL_GetSettings(settings);
    }

    if (drone) {
        settings->consoleplayer = 0;
    }

    // Set the local player and playeringame[] values.

    localplayer = settings->consoleplayer;

    for (i = 0; i < NET_MAXPLAYERS; ++i) {
        local_playeringame[i] = i < settings->num_players;
    }

    // Sync tic counters for late joiners (start_tic > 0).
    // This aligns the client's 8-bit tic sequence with the server's
    // recvwindow_start so NET_SV_ExpandTicNum works correctly.
    if (settings->start_tic > 0) {
        recvtic = settings->start_tic;
        maketic = settings->start_tic;
        gametic = settings->start_tic;
    }

    // Copy settings to global variables.

    ticdup = settings->ticdup;
    new_sync = settings->new_sync;

    if (ticdup < 1) {
        I_Error("D_StartNetGame: invalid ticdup value (%d)", ticdup);
    }

    // TODO: Message disabled until we fix new_sync.
    // if (!new_sync)
    //{
    //    printf("Syncing netgames like Vanilla Doom.\n");
    //}
}

boolean D_InitNetGame(net_connect_data_t *connect_data)
{
    boolean result = false;
    net_addr_t *addr = NULL;
    int i;

    // Call D_QuitNetGame on exit:

    I_AtExit(D_QuitNetGame, true);

    player_class = connect_data->player_class;

    //!
    // @category net
    //
    // Start a multiplayer server, listening for connections.
    //

    if (M_CheckParm("-server") > 0 || M_CheckParm("-privateserver") > 0) {
        // Server has instanceUID 1
        instanceUID = 1;
        is_host = true;
        NET_SV_Init();
        NET_SV_AddModule(&net_loop_server_module);
        NET_SV_AddModule(&net_webxdc_module);
        net_loop_client_module.InitClient();
        addr = net_loop_client_module.ResolveAddress(NULL);
        NET_ReferenceAddress(addr);
    }
    else {
        //!
        // @arg <address>
        // @category net
        //
        // Connect to a multiplayer server running on the given
        // address.
        //

        // Generate UID for this instance - it will be used as the websocketsID
        srand((unsigned int)time(NULL));
        instanceUID = rand() % 0xfffe;

        i = M_CheckParmWithArgs("-connect", 1);

        if (i > 0) {
            net_client_player = true;
            net_webxdc_module.InitClient();
            addr = net_webxdc_module.ResolveAddress("1"); // server address is 1!
            NET_ReferenceAddress(addr);
        }
    }

    printf("doom: 8, uid is %d\n", instanceUID);

    if (addr != NULL) {
        if (M_CheckParm("-drone") > 0) {
            connect_data->drone = true;
        }

        if (!NET_CL_Connect(addr, connect_data)) {
            I_Error("doom: 7, failed to connect to %s\n", NET_AddrToString(addr));
        }

        NET_ReleaseAddress(addr);

        // Wait for launch message received from server.
        NET_WaitForLaunch();

        result = true;
    }

    return result;
}

//
// D_QuitNetGame
// Called before quitting to leave a net game
// without hanging the other players
//
void D_QuitNetGame(void)
{
    NET_SV_Shutdown();
    NET_CL_Disconnect();
}

static int GetLowTic(void)
{
    int lowtic;

    lowtic = maketic;

    if (net_client_connected) {
        if (drone || recvtic < lowtic) {
            lowtic = recvtic;
        }
    }

    return lowtic;
}

static int frameon;
static int frameskip[4];
static int oldnettics;

static void OldNetSync(void)
{
    unsigned int i;
    int keyplayer = -1;

    frameon++;

    // ideally maketic should be 1 - 3 tics above lowtic
    // if we are consistantly slower, speed up time

    for (i = 0; i < NET_MAXPLAYERS; i++) {
        if (local_playeringame[i]) {
            keyplayer = i;
            break;
        }
    }

    if (keyplayer < 0) {
        // If there are no players, we can never advance anyway

        return;
    }

    if (localplayer == keyplayer) {
        // the key player does not adapt
    }
    else {
        if (maketic <= recvtic) {
            lasttime--;
            // printf ("-");
        }

        frameskip[frameon & 3] = oldnettics > recvtic;
        oldnettics = maketic;

        if (frameskip[0] && frameskip[1] && frameskip[2] && frameskip[3]) {
            skiptics = 1;
            // printf ("+");
        }
    }
}

// Returns true if there are players in the game:

static boolean PlayersInGame(void)
{
    boolean result = false;
    unsigned int i;

    // If we are connected to a server, check if there are any players
    // in the game.

    if (net_client_connected) {
        for (i = 0; i < NET_MAXPLAYERS; ++i) {
            result = result || local_playeringame[i];
        }
    }

    // Whether single or multi-player, unless we are running as a drone,
    // we are in the game.

    if (!drone) {
        result = true;
    }

    return result;
}

// When using ticdup, certain values must be cleared out when running
// the duplicate ticcmds.

static void TicdupSquash(ticcmd_set_t *set)
{
    ticcmd_t *cmd;
    unsigned int i;

    for (i = 0; i < NET_MAXPLAYERS; ++i) {
        cmd = &set->cmds[i];
        cmd->chatchar = 0;
        if (cmd->buttons & BT_SPECIAL) cmd->buttons = 0;
    }
}

// When running in single player mode, clear all the ingame[] array
// except the local player.

static void SinglePlayerClear(ticcmd_set_t *set)
{
    unsigned int i;

    for (i = 0; i < NET_MAXPLAYERS; ++i) {
        if (i != localplayer) {
            set->ingame[i] = false;
        }
    }
}

//
// TryRunTics
//

static void D_BuildAndSendWorldState(void);

void TryRunTics(void)
{
    int i;
    int lowtic;
    int entertic;
    static int oldentertics;
    int realtics;
    int availabletics;
    int counts;

    // get real tics
    entertic = I_GetTime() / ticdup;
    realtics = entertic - oldentertics;
    oldentertics = entertic;

    // in singletics mode, run a single tic every time this function
    // is called.

    if (singletics) {
        BuildNewTic();
    }
    else {
        NetUpdate();
    }

    lowtic = GetLowTic();

    availabletics = lowtic - gametic / ticdup;

    // decide how many tics to run

    if (new_sync) {
        counts = availabletics;
    }
    else {
        // decide how many tics to run
        if (realtics < availabletics - 1)
            counts = realtics + 1;
        else if (realtics < availabletics)
            counts = realtics;
        else
            counts = availabletics;

        if (counts < 1) counts = 1;

        if (net_client_connected) {
            OldNetSync();
        }
    }

    if (counts < 1) counts = 1;

    // VectorDoom: NEVER wait for remote tics. The snapshot system is the sole
    // authority for remote player state. Tics are only meaningful for the local
    // player. For remote players, we fabricate idle tics immediately so the
    // game loop always runs at full speed regardless of network conditions.

    if (net_client_connected && lowtic < gametic / ticdup + counts) {
        int target = gametic / ticdup + counts;
        // Safety: don't fabricate beyond what we've locally produced
        if (target > maketic) target = maketic;
        while (recvtic < target) {
            int idx = recvtic % BACKUPTICS;
            int p;
            for (p = 0; p < NET_MAXPLAYERS; ++p) {
                if (!drone && p == localplayer) continue;
                // Zero input: remote players idle. Snapshots drive positioning.
                memset(&ticdata[idx].cmds[p], 0, sizeof(ticcmd_t));
                // Use authoritative ingame state, not uninitialized ticdata
                ticdata[idx].ingame[p] = local_playeringame[p];
            }
            // Always ensure local player is marked in-game
            ticdata[idx].ingame[localplayer] = true;
            ++recvtic;
        }
        lowtic = GetLowTic();
    }

    // Netgame: fabrication above already handled everything.
    // Recalculate counts based on what we can actually run post-fabrication.
    if (net_client_connected) {
        counts = lowtic - gametic / ticdup;
        if (counts < 1) return;  // nothing runnable yet, try next frame
    }

    // Non-netgame only: brief wait for local tics.
    if (!net_client_connected) {
        while (!PlayersInGame() || lowtic < gametic / ticdup + counts) {
            NetUpdate();
            lowtic = GetLowTic();
            if (lowtic < gametic / ticdup) I_Error("TryRunTics: lowtic < gametic");
            if (I_GetTime() / ticdup - entertic >= MAX_NETGAME_STALL_TICS) {
                return;
            }
            I_Sleep(1);
        }
    }

    // run the count * ticdup dics
    while (counts--) {
        ticcmd_set_t *set;

        if (!PlayersInGame()) {
            return;
        }

        set = &ticdata[(gametic / ticdup) % BACKUPTICS];

        if (!net_client_connected) {
            SinglePlayerClear(set);
        }

        for (i = 0; i < ticdup; i++) {
            if (gametic / ticdup > lowtic) I_Error("gametic>lowtic");

            memcpy(local_playeringame, set->ingame, sizeof(local_playeringame));

            loop_interface->RunTic(set->cmds, set->ingame);
            gametic++;

            // Send unified world state (snapshot + health + NPC in one packet)
            if (net_client_connected && gametic % SNAPSHOT_INTERVAL == 0
                && gametic > BACKUPTICS) {
                D_BuildAndSendWorldState();
            }

            // modify command for duplicated tics

            TicdupSquash(set);
        }

        NetUpdate(); // check for new console commands
    }
}

void D_BuildAndSendSnapshot(void) {
    int data[9];
    if (!net_client_connected || !loop_interface->BuildPlayerSnapshot) return;
    loop_interface->BuildPlayerSnapshot(localplayer, data);
    NET_CL_SendPlayerState(localplayer, gametic, data);
}

// VectorDoom: unified world state — one packet with everything.
static void D_BuildAndSendWorldState(void) {
    int snap_data[9];
    int health_data[NET_MAXPLAYERS * 5];
    unsigned char npc_buf[4000];
    int npc_len = 0;

    if (!net_client_connected || !loop_interface->BuildPlayerSnapshot) return;

    // Build player snapshot
    loop_interface->BuildPlayerSnapshot(localplayer, snap_data);

    // Build host authority data if we're the host
    if (is_host) {
        if (loop_interface->BuildHealthAuth)
            loop_interface->BuildHealthAuth(health_data);

        extern int P_BuildNPCSnapshot(unsigned char *buf, int maxlen);
        npc_len = P_BuildNPCSnapshot(npc_buf, sizeof(npc_buf));
        if (npc_len < 0) npc_len = 0;
    }

    NET_CL_SendWorldState(localplayer, gametic, snap_data,
                          is_host, health_data, NET_MAXPLAYERS,
                          npc_buf, npc_len);
}

void D_ApplyPlayerSnapshot(int player, int gametic_snap, int *data) {
    if (player == localplayer) return;  // never correct own player
    if (!loop_interface->ApplyPlayerSnapshot) return;
    loop_interface->ApplyPlayerSnapshot(player, data);
}

// VectorDoom: called by server when a client disconnects/times out.
// Marks the player as no longer in game so PlayerQuitGame fires in RunTic.
void D_PlayerDisconnected(int player) {
    if (player >= 0 && player < NET_MAXPLAYERS) {
        local_playeringame[player] = false;
        printf("doom: player %d marked disconnected\n", player);
    }
}

void D_BuildAndSendHealthAuth(void) {
    int data[NET_MAXPLAYERS * 5];
    if (!net_client_connected || !loop_interface->BuildHealthAuth) return;
    loop_interface->BuildHealthAuth(data);
    NET_CL_SendHealthAuth(data, NET_MAXPLAYERS);
}

void D_ApplyHealthAuth(int *data) {
    if (!loop_interface->ApplyHealthAuth) return;
    loop_interface->ApplyHealthAuth(localplayer, data);
}

// Host receives respawn request from a client — respawn them on host's game
void D_HandleRespawnRequest(int player) {
    if (!loop_interface || !loop_interface->HandleRespawnRequest) return;
    loop_interface->HandleRespawnRequest(player);
}

// Mid-game join: activate a new player on this machine
void D_PlayerJoinedMidGame(int player) {
    if (player < 0 || player >= NET_MAXPLAYERS) return;
    local_playeringame[player] = true;
    if (loop_interface && loop_interface->PlayerJoined)
        loop_interface->PlayerJoined(player);
}

// Client sends respawn request to host
void D_SendRespawnRequest(void) {
    if (!net_client_connected) return;
    NET_CL_SendRespawnRequest(localplayer);
}

// Client sends damage event to host: "I hit target_player for damage"
void D_SendDamageEvent(int source_player, int target_player, int damage) {
    if (!net_client_connected) return;
    NET_CL_SendDamageEvent(source_player, target_player, damage);
}

// Host receives damage event from client — apply via game layer
void D_HandleDamageEvent(int source_player, int target_player, int damage) {
    if (!loop_interface || !loop_interface->HandleDamageEvent) return;
    loop_interface->HandleDamageEvent(source_player, target_player, damage);
}

// Host builds and sends NPC state snapshot to all clients
void D_BuildAndSendNPCState(void) {
    unsigned char buf[4000];
    int len;
    extern int P_BuildNPCSnapshot(unsigned char *buf, int maxlen);
    if (!net_client_connected) return;
    len = P_BuildNPCSnapshot(buf, sizeof(buf));
    if (len > 0) {
        NET_CL_SendNPCState(buf, len);
    }
}

// Client applies received NPC state snapshot
void D_ApplyNPCState(unsigned char *data, int len) {
    extern void P_ApplyNPCSnapshot(unsigned char *buf, int len);
    P_ApplyNPCSnapshot(data, len);
}

// Client sends NPC damage event to host
void D_SendNPCDamageEvent(int source_player, unsigned short target_net_id, int damage) {
    if (!net_client_connected) return;
    NET_CL_SendNPCDamage(source_player, target_net_id, damage);
}

// Host receives NPC damage event from client — apply via game layer
void D_HandleNPCDamageEvent(int source_player, unsigned short target_net_id, int damage) {
    if (!loop_interface || !loop_interface->HandleNPCDamageEvent) return;
    loop_interface->HandleNPCDamageEvent(source_player, target_net_id, damage);
}

// Client sends USE event to host: "I pressed USE"
void D_SendUseEvent(int player) {
    if (!net_client_connected) return;
    NET_CL_SendUseEvent(player);
}

// Host receives USE event from client — apply via game layer
void D_HandleUseEvent(int player) {
    if (!loop_interface || !loop_interface->HandleUseEvent) return;
    loop_interface->HandleUseEvent(player);
}

// Chat messages: full message sent as a packet (bypasses ticcmd chatchar)
void D_SendChatMessage(int player, const char *msg) {
    if (!net_client_connected) return;
    NET_CL_SendChatMessage(player, msg);
}

void D_HandleChatMessage(int player, const char *msg) {
    extern void HU_DisplayNetMessage(int player, const char *msg);
    HU_DisplayNetMessage(player, msg);
}

// Player name exchange
void D_SendPlayerName(int player, const char *name) {
    if (!net_client_connected) return;
    NET_CL_SendPlayerName(player, name);
}

void D_HandlePlayerName(int player, const char *name) {
    extern void HU_SetPlayerName(int player, const char *name);
    HU_SetPlayerName(player, name);
}

// Kill messages: host broadcasts kill notifications
void D_SendKillMessage(const char *msg) {
    if (!net_client_connected) return;
    NET_CL_SendKillMessage(msg);
}

void D_HandleKillMessage(const char *msg) {
    extern void HU_DisplayKillMessage(const char *msg);
    HU_DisplayKillMessage(msg);
}

void D_RegisterLoopCallbacks(loop_interface_t *i) { loop_interface = i; }

// TODO: Move nonvanilla demo functions into a dedicated file.
#include "m_misc.h"
#include "w_wad.h"

static boolean StrictDemos(void)
{
    //!
    // @category demo
    //
    // When recording or playing back demos, disable any extensions
    // of the vanilla demo format - record demos as vanilla would do,
    // and play back demos as vanilla would do.
    //
    return M_ParmExists("-strictdemos");
}

// If the provided conditional value is true, we're trying to record
// a demo file that will include a non-vanilla extension. The function
// will return true if the conditional is true and it's allowed to use
// this extension (no extensions are allowed if -strictdemos is given
// on the command line). A warning is shown on the console using the
// provided string describing the non-vanilla expansion.
boolean D_NonVanillaRecord(boolean conditional, const char *feature)
{
    if (!conditional || StrictDemos()) {
        return false;
    }

    printf("Warning: Recording a demo file with a non-vanilla extension "
           "(%s). Use -strictdemos to disable this extension.\n",
           feature);

    return true;
}

// Returns true if the given lump number corresponds to data from a .lmp
// file, as opposed to a WAD.
static boolean IsDemoFile(int lumpnum)
{
    char *lower;
    boolean result;

    lower = M_StringDuplicate(lumpinfo[lumpnum]->wad_file->path);
    M_ForceLowercase(lower);
    result = M_StringEndsWith(lower, ".lmp");
    free(lower);

    return result;
}

// If the provided conditional value is true, we're trying to play back
// a demo that includes a non-vanilla extension. We return true if the
// conditional is true and it's allowed to use this extension, checking
// that:
//  - The -strictdemos command line argument is not provided.
//  - The given lumpnum identifying the demo to play back identifies a
//    demo that comes from a .lmp file, not a .wad file.
//  - Before proceeding, a warning is shown to the user on the console.
boolean D_NonVanillaPlayback(boolean conditional, int lumpnum, const char *feature)
{
    if (!conditional || StrictDemos()) {
        return false;
    }

    if (!IsDemoFile(lumpnum)) {
        printf("Warning: WAD contains demo with a non-vanilla extension "
               "(%s)\n",
               feature);
        return false;
    }

    printf("Warning: Playing back a demo file with a non-vanilla extension "
           "(%s). Use -strictdemos to disable this extension.\n",
           feature);

    return true;
}
