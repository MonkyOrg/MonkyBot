//
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// Network client code
//

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#include "deh_main.h"
#include "deh_str.h"
#include "doomtype.h"
#include "i_system.h"
#include "i_timer.h"
#include "m_argv.h"
#include "m_config.h"
#include "m_fixed.h"
#include "m_misc.h"
#include "net_client.h"
#include "net_common.h"
#include "net_defs.h"
#include "net_gui.h"
#include "net_io.h"
#include "net_packet.h"
#include "net_petname.h"
#include "net_query.h"
#include "net_server.h"
#include "net_structrw.h"
#include "w_checksum.h"
#include "w_wad.h"

extern void D_ReceiveTic(ticcmd_t *ticcmds, boolean *playeringame);

typedef enum {
    // waiting for the game to launch

    CLIENT_STATE_WAITING_LAUNCH,

    // waiting for the game to start

    CLIENT_STATE_WAITING_START,

    // in game

    CLIENT_STATE_IN_GAME,

} net_clientstate_t;

// Type of structure used in the receive window

typedef struct {
    // Whether this tic has been received yet

    boolean active;

    // Last time we sent a resend request for this tic

    unsigned int resend_time;

    // Tic data from server

    net_full_ticcmd_t cmd;

} net_server_recv_t;

// Type of structure used in the send window

typedef struct {
    // Whether this slot is active yet

    boolean active;

    // The tic number

    unsigned int seq;

    // Time the command was generated

    unsigned int time;

    // Ticcmd diff

    net_ticdiff_t cmd;
} net_server_send_t;

extern fixed_t offsetms;

static net_connection_t client_connection;
static net_clientstate_t client_state;
static net_addr_t *server_addr;
static net_context_t *client_context;

// game settings, as received from the server when the game started

static net_gamesettings_t settings;

// Why did the server reject us?
char *net_client_reject_reason = NULL;

// true if the client code is in use

boolean net_client_connected;

// true if we have received waiting data from the server,
// and the wait data that was received.

boolean net_client_received_wait_data;
net_waitdata_t net_client_wait_data;

// Waiting at the initial wait screen for the game to be launched?

boolean net_waiting_for_launch = false;

// Name that we send to the server

char *net_player_name = NULL;

// Connected but not participating in the game (observer)

boolean drone = false;

// The last ticcmd constructed

static ticcmd_t last_ticcmd;

// Buffer of ticcmd diffs being sent to the server

static net_server_send_t send_queue[BACKUPTICS];

// Receive window

static ticcmd_t recvwindow_cmd_base[NET_MAXPLAYERS];
static int recvwindow_start;
static net_server_recv_t recvwindow[BACKUPTICS];

// Whether we need to send an acknowledgement and
// when gamedata was last received.

static boolean need_to_acknowledge;
static unsigned int gamedata_recv_time;

// The latency (time between when we sent our command and we got all
// the other players' commands from the server) for the last tic we
// received. We include this latency in tics we send to the server so
// that they can adjust to us.
static int last_latency;

// Ping/pong RTT measurement (separate from tic sync latency)
static int ping_rtt = 0;           // smoothed RTT in milliseconds
static unsigned int ping_send_time = 0;  // when we last sent a PING
#define PING_INTERVAL_MS 2000       // send a ping every 2 seconds

int NET_CL_GetLatency(void) { return ping_rtt; }

// Hash checksums of our wad directory and dehacked data.

sha1_digest_t net_local_wad_sha1sum;
sha1_digest_t net_local_deh_sha1sum;

// Are we playing with the freedoom IWAD?

unsigned int net_local_is_freedoom;

#define NET_CL_ExpandTicNum(b) NET_ExpandTicNum(recvwindow_start, (b))

// Called when we become disconnected from the server

static void NET_CL_Disconnected(void) { D_ReceiveTic(NULL, NULL); }

// Called when a packet is received from the server containing game
// data. This updates the clock synchronization variable (offsetms)
// using a PID filter that keeps client clocks in sync.
static void UpdateClockSync(unsigned int seq, unsigned int remote_latency)
{
    static int last_error, cumul_error;
    int latency, error;

    if (seq == send_queue[seq % BACKUPTICS].seq) {
        latency = I_GetTimeMS() - send_queue[seq % BACKUPTICS].time;
    }
    else if (seq > send_queue[seq % BACKUPTICS].seq) {
        // We have received the ticcmd from the server before we have
        // even sent ours

        latency = 0;
    }
    else {
        return;
    }

    // PID filter. These are manually trained parameters.
#define KP 0.1
#define KI 0.01
#define KD 0.02

    // How does our latency compare to the worst other player?
    error = latency - remote_latency;
    cumul_error += error;

    offsetms = KP * (FRACUNIT * error) - KI * (FRACUNIT * cumul_error) + (KD * FRACUNIT) * (last_error - error);

    last_error = error;
    last_latency = latency;

    NET_Log("client: latency %d, remote %d -> offset=%dms, cumul_error=%d", latency, remote_latency,
            offsetms / FRACUNIT, cumul_error);
}

// Expand a net_full_ticcmd_t, applying the diffs in cmd->cmds as
// patches against recvwindow_cmd_base.  Place the results into
// the d_net.c structures (netcmds/nettics) and save the new ticcmd
// back into recvwindow_cmd_base.

static void NET_CL_ExpandFullTiccmd(net_full_ticcmd_t *cmd, unsigned int seq, ticcmd_t *ticcmds)
{
    int i;

    // Expand tic diffs for all players

    for (i = 0; i < NET_MAXPLAYERS; ++i) {
        if (i == settings.consoleplayer && !drone) {
            continue;
        }

        if (cmd->playeringame[i]) {
            net_ticdiff_t *diff;

            diff = &cmd->cmds[i];

            // Use the ticcmd diff to patch the previous ticcmd to
            // the new ticcmd

            NET_TiccmdPatch(&recvwindow_cmd_base[i], diff, &ticcmds[i]);

            // Store a copy for next time

            recvwindow_cmd_base[i] = ticcmds[i];
        }
    }
}

// Advance the receive window

static void NET_CL_AdvanceWindow(void)
{
    ticcmd_t ticcmds[NET_MAXPLAYERS];

    while (recvwindow[0].active) {
        // Expand tic diff data into d_net.c structures

        NET_CL_ExpandFullTiccmd(&recvwindow[0].cmd, recvwindow_start, ticcmds);
        D_ReceiveTic(ticcmds, recvwindow[0].cmd.playeringame);

        // Advance the window

        memmove(recvwindow, recvwindow + 1, sizeof(net_server_recv_t) * (BACKUPTICS - 1));
        memset(&recvwindow[BACKUPTICS - 1], 0, sizeof(net_server_recv_t));

        ++recvwindow_start;

        NET_Log("client: advanced receive window to %d", recvwindow_start);
    }
}

// Shut down the client code, etc.  Invoked after a disconnect.

static void NET_CL_Shutdown(void)
{
    if (net_client_connected) {
        net_client_connected = false;

        NET_ReleaseAddress(server_addr);

        // Shut down network module, etc.  To do.
    }
}

void NET_CL_LaunchGame(void) { NET_Conn_NewReliable(&client_connection, NET_PACKET_TYPE_LAUNCH); }

void NET_CL_StartGame(net_gamesettings_t *settings)
{
    net_packet_t *packet;

    // Start from a ticcmd of all zeros

    memset(&last_ticcmd, 0, sizeof(ticcmd_t));

    // Send packet

    packet = NET_Conn_NewReliable(&client_connection, NET_PACKET_TYPE_GAMESTART);

    NET_WriteSettings(packet, settings);
}

static void NET_CL_SendGameDataACK(void)
{
    net_packet_t *packet;

    packet = NET_NewPacket(10);

    NET_WriteInt16(packet, NET_PACKET_TYPE_GAMEDATA_ACK);
    NET_WriteInt8(packet, recvwindow_start & 0xff);

    NET_Conn_SendPacket(&client_connection, packet);

    NET_FreePacket(packet);

    need_to_acknowledge = false;
}

static void NET_CL_SendTics(int start, int end)
{
    net_packet_t *packet;
    int i;

    if (!net_client_connected) {
        // Disconnected from server

        return;
    }

    if (start < 0) start = 0;

    // Build a new packet to send to the server

    packet = NET_NewPacket(512);
    NET_WriteInt16(packet, NET_PACKET_TYPE_GAMEDATA);

    // Write the start tic and number of tics.  Send only the low byte
    // of start - it can be inferred by the server.

    NET_WriteInt8(packet, recvwindow_start & 0xff);
    NET_WriteInt8(packet, start & 0xff);
    NET_WriteInt8(packet, end - start + 1);

    // Add the tics.

    for (i = start; i <= end; ++i) {
        net_server_send_t *sendobj;

        sendobj = &send_queue[i % BACKUPTICS];

        NET_WriteInt16(packet, last_latency);

        NET_WriteTiccmdDiff(packet, &sendobj->cmd, settings.lowres_turn);
    }

    // Send the packet

    NET_Conn_SendPacket(&client_connection, packet);

    // All done!

    NET_FreePacket(packet);

    // Acknowledgement has been sent as part of the packet

    need_to_acknowledge = false;
}

// Add a new ticcmd to the send queue

void NET_CL_SendTiccmd(ticcmd_t *ticcmd, int maketic)
{
    net_ticdiff_t diff;
    net_server_send_t *sendobj;
    int starttic, endtic;

    // Calculate the difference to the last ticcmd

    NET_TiccmdDiff(&last_ticcmd, ticcmd, &diff);

    // Store in the send queue

    sendobj = &send_queue[maketic % BACKUPTICS];
    sendobj->active = true;
    sendobj->seq = maketic;
    sendobj->time = I_GetTimeMS();
    sendobj->cmd = diff;

    last_ticcmd = *ticcmd;

    // Send to server.

    starttic = maketic - settings.extratics;
    endtic = maketic;

    if (starttic < 0) starttic = 0;

    NET_Log("client: generated tic %d, sending %d-%d", maketic, starttic, endtic);
    NET_CL_SendTics(starttic, endtic);
}

// Parse a SYN packet received back from the server indicating a successful
// connection attempt.
static void NET_CL_ParseSYN(net_packet_t *packet)
{
    net_protocol_t protocol;
    char *server_version;

    NET_Log("client: processing SYN response");

    server_version = NET_ReadSafeString(packet);
    if (server_version == NULL) {
        NET_Log("client: error: failed to read server version");
        return;
    }

    protocol = NET_ReadProtocol(packet);
    if (protocol == NET_PROTOCOL_UNKNOWN) {
        NET_Log("client: error: can't find a common protocol");
        return;
    }

    // We are now successfully connected.
    NET_Log("client: connected to server");
    client_connection.state = NET_CONN_STATE_CONNECTED;
    client_connection.protocol = protocol;

    // Even though we have negotiated a compatible protocol, the game may still
    // desync. Chocolate Doom's philosophy makes this unlikely, but if we're
    // playing with a forked version, or even against a different version that
    // fixes a compatibility issue, we may still have problems.
    if (strcmp(server_version, PACKAGE_STRING) != 0) {
        fprintf(stderr,
                "NET_CL_ParseSYN: This is '%s', but the server is "
                "'%s'. It is possible that this mismatch may cause the game "
                "to desync.\n",
                PACKAGE_STRING, server_version);
    }
}

static void SetRejectReason(const char *s)
{
    free(net_client_reject_reason);
    if (s != NULL) {
        net_client_reject_reason = strdup(s);
    }
    else {
        net_client_reject_reason = NULL;
    }
}

static void NET_CL_ParseReject(net_packet_t *packet)
{
    char *msg;

    msg = NET_ReadSafeString(packet);
    if (msg == NULL) {
        return;
    }

    if (client_connection.state == NET_CONN_STATE_CONNECTING) {
        client_connection.state = NET_CONN_STATE_DISCONNECTED;
        client_connection.disconnect_reason = NET_DISCONNECT_REMOTE;
        SetRejectReason(msg);
    }
}

// data received while we are waiting for the game to start

static void NET_CL_ParseWaitingData(net_packet_t *packet)
{
    net_waitdata_t wait_data;

    if (!NET_ReadWaitData(packet, &wait_data)) {
        // Invalid packet?
        return;
    }

    if (wait_data.num_players > wait_data.max_players || wait_data.ready_players > wait_data.num_players ||
        wait_data.max_players > NET_MAXPLAYERS) {
        // insane data

        return;
    }

    if ((wait_data.consoleplayer >= 0 && drone) || (wait_data.consoleplayer < 0 && !drone) ||
        (wait_data.consoleplayer >= wait_data.num_players)) {
        // Invalid player number

        return;
    }

    memcpy(&net_client_wait_data, &wait_data, sizeof(net_waitdata_t));
    net_client_received_wait_data = true;
}

static void NET_CL_ParseLaunch(net_packet_t *packet)
{
    unsigned int num_players;

    NET_Log("client: processing launch packet");

    if (client_state != CLIENT_STATE_WAITING_LAUNCH) {
        NET_Log("client: error: not in waiting launch state, client_state=%d", client_state);
        return;
    }

    // The launch packet contains the number of players that will be
    // in the game when it starts, so that we can do the startup
    // progress indicator (the wait data is unreliable).

    if (!NET_ReadInt8(packet, &num_players)) {
        NET_Log("client: error: failed to read number of players");
        return;
    }

    net_client_wait_data.num_players = num_players;
    client_state = CLIENT_STATE_WAITING_START;
    NET_Log("client: now waiting for game start");
}

static void NET_CL_ParseGameStart(net_packet_t *packet)
{
    NET_Log("client: processing game start packet");

    if (!NET_ReadSettings(packet, &settings)) {
        NET_Log("client: error: failed to read settings");
        return;
    }

    if (client_state != CLIENT_STATE_WAITING_START) {
        NET_Log("client: error: not in waiting start state, client_state=%d", client_state);
        return;
    }

    if (settings.num_players > NET_MAXPLAYERS || settings.consoleplayer >= (signed int)settings.num_players) {
        // insane values
        NET_Log("client: error: bad settings, num_players=%d, consoleplayer=%d", settings.num_players,
                settings.consoleplayer);
        return;
    }

    if ((drone && settings.consoleplayer >= 0) || (!drone && settings.consoleplayer < 0)) {
        // Invalid player number: must be positive for real players,
        // negative for drones
        NET_Log("client: error: mismatch: drone=%d, consoleplayer=%d", drone, settings.consoleplayer);
        return;
    }

    NET_Log("client: beginning game state");
    client_state = CLIENT_STATE_IN_GAME;

    // Clear the receive window

    memset(recvwindow, 0, sizeof(recvwindow));
    recvwindow_start = settings.start_tic;  // 0 for normal, >0 for late join
    memset(&recvwindow_cmd_base, 0, sizeof(recvwindow_cmd_base));

    // Clear the send queue

    memset(&send_queue, 0x00, sizeof(send_queue));
}

static void NET_CL_SendResendRequest(int start, int end)
{
    net_packet_t *packet;
    unsigned int nowtime;
    int i;

    // printf("CL: Send resend %i-%i\n", start, end);

    packet = NET_NewPacket(64);
    NET_WriteInt16(packet, NET_PACKET_TYPE_GAMEDATA_RESEND);
    NET_WriteInt32(packet, start);
    NET_WriteInt8(packet, end - start + 1);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);

    nowtime = I_GetTimeMS();

    // Save the time we sent the resend request

    for (i = start; i <= end; ++i) {
        int index;

        index = i - recvwindow_start;

        if (index < 0 || index >= BACKUPTICS) continue;

        recvwindow[index].resend_time = nowtime;
    }
}

// Check for expired resend requests

static void NET_CL_CheckResends(void)
{
    unsigned int nowtime;

    // VectorDoom: Resend requests disabled.
    // Tic transfer is no longer required for gameplay — the snapshot system
    // is the sole authority for remote player state. Resend flooding only
    // congests the Iroh gossip channel during lag spikes.

    nowtime = I_GetTimeMS();

    // Still send ACKs so the server knows we're alive
    if (need_to_acknowledge && nowtime - gamedata_recv_time > 200) {
        NET_CL_SendGameDataACK();
    }
}

// Parsing of NET_PACKET_TYPE_GAMEDATA packets
// (packets containing the actual ticcmd data)

static void NET_CL_ParseGameData(net_packet_t *packet)
{
    net_server_recv_t *recvobj;
    unsigned int seq, num_tics;
    unsigned int nowtime;
    int resend_start, resend_end;
    size_t i;
    int index;

    NET_Log("client: processing game data packet");

    // Read header
    if (!NET_ReadInt8(packet, &seq) || !NET_ReadInt8(packet, &num_tics)) {
        NET_Log("client: error: failed to read header");
        return;
    }

    nowtime = I_GetTimeMS();

    // Whatever happens, we now need to send an acknowledgement of our
    // current receive point.

    if (!need_to_acknowledge) {
        need_to_acknowledge = true;
        gamedata_recv_time = nowtime;
    }

    // Expand byte value into the full tic number
    seq = NET_CL_ExpandTicNum(seq);
    NET_Log("client: got game data, seq=%d, num_tics=%d", seq, num_tics);

    for (i = 0; i < num_tics; ++i) {
        net_full_ticcmd_t cmd;

        index = seq - recvwindow_start + i;

        if (!NET_ReadFullTiccmd(packet, &cmd, settings.lowres_turn)) {
            NET_Log("client: error: failed to read ticcmd %d", i);
            return;
        }

        if (index < 0 || index >= BACKUPTICS) {
            // Out of range of the recv window

            continue;
        }

        // Store in the receive window

        recvobj = &recvwindow[index];

        recvobj->active = true;
        recvobj->cmd = cmd;
        NET_Log("client: stored tic %d in receive window", seq + i);

        // If a packet is lost or arrives out of order, we might get
        // the tic in the next packet instead (because of extratic).
        // If that's the case then the latency for receiving that tic
        // now will be bogus. So we only use the last tic in the packet
        // to trigger a clock sync update.
        if (i == num_tics - 1) {
            UpdateClockSync(seq + i, cmd.latency);
        }
    }

    // Has this been received out of sequence, ie. have we not received
    // all tics before the first tic in this packet?  If so, send a
    // resend request.

    // printf("CL: %p: %i\n", client, seq);

    resend_end = seq - recvwindow_start;

    if (resend_end <= 0) return;

    if (resend_end >= BACKUPTICS) resend_end = BACKUPTICS - 1;

    index = resend_end - 1;
    resend_start = resend_end;

    while (index >= 0) {
        recvobj = &recvwindow[index];

        if (recvobj->active) {
            // ended our run of unreceived tics

            break;
        }

        if (recvobj->resend_time != 0) {
            // Already sent a resend request for this tic

            break;
        }

        resend_start = index;
        --index;
    }

    // Possibly send a resend request
    if (resend_start < resend_end) {
        NET_Log("client: request resend for %d-%d before %d", recvwindow_start + resend_start,
                recvwindow_start + resend_end - 1, seq);
        NET_CL_SendResendRequest(recvwindow_start + resend_start, recvwindow_start + resend_end - 1);
    }
}

// Parse a resend request from the server due to a dropped packet

static void NET_CL_ParseResendRequest(net_packet_t *packet)
{
    static unsigned int start;
    static unsigned int end;
    static unsigned int num_tics;

    NET_Log("client: processing resend request");

    if (drone) {
        // Drones don't send gamedata.
        NET_Log("client: error: resend request but we're a drone?");
        return;
    }

    if (!NET_ReadInt32(packet, &start) || !NET_ReadInt8(packet, &num_tics)) {
        NET_Log("client: error: couldn't read start and num_tics");
        return;
    }

    end = start + num_tics - 1;

    // printf("requested resend %i-%i .. ", start, end);
    NET_Log("client: resend request: start=%d, num_tics=%d", start, num_tics);

    // Check we have the tics being requested.  If not, reduce the
    // window of tics to only what we have.

    while (start <= end && (!send_queue[start % BACKUPTICS].active || send_queue[start % BACKUPTICS].seq != start)) {
        ++start;
    }

    while (start <= end && (!send_queue[end % BACKUPTICS].active || send_queue[end % BACKUPTICS].seq != end)) {
        --end;
    }

    // Resend those tics
    if (start <= end) {
        NET_Log("client: resending %d-%d", start, end);
        NET_CL_SendTics(start, end);
    }
    else {
        NET_Log("client: don't have the tics to resend");
    }
}

// Console message that the server wants the client to print

static void NET_CL_ParseConsoleMessage(net_packet_t *packet)
{
    char *msg;

    msg = NET_ReadSafeString(packet);

    if (msg == NULL) {
        return;
    }

    printf("Message from server:\n%s\n", msg);
}

// Send player state snapshot to server for desync correction

void NET_CL_SendPlayerState(int player, int gametic, int *data) {
    net_packet_t *packet;
    int i;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(48);
    NET_WriteInt16(packet, NET_PACKET_TYPE_PLAYER_STATE);
    NET_WriteInt8(packet, player);
    NET_WriteInt32(packet, gametic);
    for (i = 0; i < 9; i++) NET_WriteInt32(packet, (unsigned int)data[i]);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

// Parse player state snapshot received from server (9 ints)

extern void D_ApplyPlayerSnapshot(int player, int gametic_snap, int *data);

static void NET_CL_ParsePlayerState(net_packet_t *packet) {
    unsigned int player, tick;
    int data[9], i;
    if (!NET_ReadInt8(packet, &player)) return;
    if (!NET_ReadInt32(packet, &tick)) return;
    for (i = 0; i < 9; i++) {
        if (!NET_ReadSInt32(packet, &data[i])) return;
    }
    if (player < NET_MAXPLAYERS) {
        D_ApplyPlayerSnapshot(player, tick, data);
    }
}

// Send host-authoritative health broadcast for all players

void NET_CL_SendHealthAuth(int *data, int num_players) {
    net_packet_t *packet;
    int i;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4 + num_players * 20);
    NET_WriteInt16(packet, NET_PACKET_TYPE_HEALTH_AUTH);
    NET_WriteInt8(packet, num_players);
    for (i = 0; i < num_players * 5; i++) NET_WriteInt32(packet, (unsigned int)data[i]);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

// Parse host-authoritative health broadcast

extern void D_ApplyHealthAuth(int *data);

static void NET_CL_ParseHealthAuth(net_packet_t *packet) {
    unsigned int num_players;
    int data[NET_MAXPLAYERS * 5], i;
    if (!NET_ReadInt8(packet, &num_players)) return;
    if (num_players > NET_MAXPLAYERS) return;
    for (i = 0; i < (int)num_players * 5; i++) {
        if (!NET_ReadSInt32(packet, &data[i])) return;
    }
    D_ApplyHealthAuth(data);
}

// Send respawn request to host

void NET_CL_SendRespawnRequest(int player) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4);
    NET_WriteInt16(packet, NET_PACKET_TYPE_RESPAWN_REQUEST);
    NET_WriteInt8(packet, player);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

// Send damage event to host: "I (source) hit target for damage"

void NET_CL_SendDamageEvent(int source_player, int target_player, int damage) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(8);
    NET_WriteInt16(packet, NET_PACKET_TYPE_DAMAGE_EVENT);
    NET_WriteInt8(packet, source_player);
    NET_WriteInt8(packet, target_player);
    NET_WriteInt16(packet, damage);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

void NET_CL_SendNPCState(unsigned char *data, int len) {
    net_packet_t *packet;
    int i;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(len + 4);
    NET_WriteInt16(packet, NET_PACKET_TYPE_NPC_STATE);
    for (i = 0; i < len; i++)
        NET_WriteInt8(packet, data[i]);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

// VectorDoom: unified world state — compact encoding.
// Player snapshot: x(4) y(4) z(4) angle(2) momx(2) momy(2) momz(2) attack(1) latency(2) = 23 bytes
// Health auth per player: health(2) state(1) kills(2) items(2) secrets(2) = 9 bytes × 4 = 36 bytes
// Total fixed: ~65 bytes (was ~128). Plus NPC data (already compact).

void NET_CL_SendWorldState(int player, int gametic_val,
                           int *snap_data,
                           boolean is_host_flag,
                           int *health_data, int num_players,
                           unsigned char *npc_data, int npc_len)
{
    net_packet_t *packet;
    int i;
    if (client_state != CLIENT_STATE_IN_GAME) return;

    packet = NET_NewPacket(128 + (npc_len > 0 ? npc_len : 0));
    NET_WriteInt16(packet, NET_PACKET_TYPE_WORLD_STATE);

    // Player snapshot — compact encoding
    NET_WriteInt8(packet, player);
    NET_WriteInt32(packet, gametic_val);
    NET_WriteInt32(packet, (unsigned int)snap_data[0]);  // x (full precision)
    NET_WriteInt32(packet, (unsigned int)snap_data[1]);  // y (full precision)
    NET_WriteInt32(packet, (unsigned int)snap_data[2]);  // z (full precision)
    NET_WriteInt8(packet, (unsigned int)snap_data[3] >> 24);  // angle top 8 bits (~1.4° steps)
    NET_WriteInt16(packet, (unsigned int)((snap_data[4] + 128) >> 8));  // momx /256
    NET_WriteInt16(packet, (unsigned int)((snap_data[5] + 128) >> 8));  // momy /256
    NET_WriteInt16(packet, (unsigned int)((snap_data[6] + 128) >> 8));  // momz /256
    NET_WriteInt8(packet, snap_data[7]);   // attack_weapon (0-9)
    NET_WriteInt16(packet, snap_data[8]);  // latency ms

    // Host authority section
    NET_WriteInt8(packet, is_host_flag ? 1 : 0);
    if (is_host_flag) {
        // Health auth — compact: int16 health, uint8 state, uint16 kills/items/secrets
        NET_WriteInt8(packet, num_players);
        for (i = 0; i < num_players; i++) {
            NET_WriteInt16(packet, (unsigned int)health_data[i * 5]);      // health
            NET_WriteInt8(packet, health_data[i * 5 + 1]);                 // playerstate
            NET_WriteInt16(packet, (unsigned int)health_data[i * 5 + 2]);  // killcount
            NET_WriteInt16(packet, (unsigned int)health_data[i * 5 + 3]);  // itemcount
            NET_WriteInt16(packet, (unsigned int)health_data[i * 5 + 4]);  // secretcount
        }
        // NPC state (already compact binary)
        NET_WriteInt16(packet, npc_len);
        for (i = 0; i < npc_len; i++)
            NET_WriteInt8(packet, npc_data[i]);
    }

    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

extern void D_ApplyPlayerSnapshot(int player, int gametic_snap, int *data);
extern void D_ApplyHealthAuth(int *data);
extern void D_ApplyNPCState(unsigned char *data, int len);

static void NET_CL_ParseWorldState(net_packet_t *packet) {
    unsigned int player, tick, is_host_pkt, val;
    int snap_data[9], i;

    // VectorDoom: count world state as "gamedata received" to keep the
    // connection alive. Without this, clients disconnect if tic flow is
    // disabled (gamedata_recv_time never updates).
    gamedata_recv_time = I_GetTimeMS();

    // Player snapshot — compact decoding
    if (!NET_ReadInt8(packet, &player)) return;
    if (!NET_ReadInt32(packet, &tick)) return;
    if (!NET_ReadSInt32(packet, &snap_data[0])) return;  // x
    if (!NET_ReadSInt32(packet, &snap_data[1])) return;  // y
    if (!NET_ReadSInt32(packet, &snap_data[2])) return;  // z
    if (!NET_ReadInt8(packet, &val)) return;
    snap_data[3] = (int)(val << 24);  // angle: restore 8-bit to 32-bit
    if (!NET_ReadInt16(packet, &val)) return;
    snap_data[4] = (int)((short)val) << 8;  // momx: restore ×256
    if (!NET_ReadInt16(packet, &val)) return;
    snap_data[5] = (int)((short)val) << 8;  // momy: restore ×256
    if (!NET_ReadInt16(packet, &val)) return;
    snap_data[6] = (int)((short)val) << 8;  // momz: restore ×256
    if (!NET_ReadInt8(packet, &val)) return;
    snap_data[7] = val;  // attack_weapon
    if (!NET_ReadInt16(packet, &val)) return;
    snap_data[8] = val;  // latency

    if (player < NET_MAXPLAYERS) {
        D_ApplyPlayerSnapshot(player, tick, snap_data);
    }

    // Host authority section
    if (!NET_ReadInt8(packet, &is_host_pkt)) return;
    if (is_host_pkt) {
        // Health auth — compact decoding
        unsigned int num_players;
        int health_data[NET_MAXPLAYERS * 5];
        if (!NET_ReadInt8(packet, &num_players)) return;
        if (num_players > NET_MAXPLAYERS) return;
        for (i = 0; i < (int)num_players; i++) {
            if (!NET_ReadInt16(packet, &val)) return;
            health_data[i * 5] = (int)(short)val;      // health (signed)
            if (!NET_ReadInt8(packet, &val)) return;
            health_data[i * 5 + 1] = val;               // playerstate
            if (!NET_ReadInt16(packet, &val)) return;
            health_data[i * 5 + 2] = val;               // killcount
            if (!NET_ReadInt16(packet, &val)) return;
            health_data[i * 5 + 3] = val;               // itemcount
            if (!NET_ReadInt16(packet, &val)) return;
            health_data[i * 5 + 4] = val;               // secretcount
        }
        D_ApplyHealthAuth(health_data);

        // NPC state
        unsigned int npc_len;
        if (!NET_ReadInt16(packet, &npc_len)) return;
        if (npc_len > 0 && npc_len < 4096) {
            unsigned char npc_buf[4096];
            for (i = 0; i < (int)npc_len; i++) {
                if (!NET_ReadInt8(packet, &val)) return;
                npc_buf[i] = (unsigned char)val;
            }
            D_ApplyNPCState(npc_buf, npc_len);
        }
    }
}

void NET_CL_SendNPCDamage(int source_player, unsigned short target_net_id, int damage) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(10);
    NET_WriteInt16(packet, NET_PACKET_TYPE_NPC_DAMAGE);
    NET_WriteInt8(packet, source_player);
    NET_WriteInt16(packet, target_net_id);
    NET_WriteInt16(packet, damage < 65535 ? damage : 65535);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

void NET_CL_SendUseEvent(int player) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4);
    NET_WriteInt16(packet, NET_PACKET_TYPE_USE_EVENT);
    NET_WriteInt8(packet, player);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

void NET_CL_SendChatMessage(int player, const char *msg) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4 + (int)strlen(msg));
    NET_WriteInt16(packet, NET_PACKET_TYPE_CHAT_MSG);
    NET_WriteInt8(packet, player);
    NET_WriteString(packet, msg);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

void NET_CL_SendPlayerName(int player, const char *name) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4 + (int)strlen(name));
    NET_WriteInt16(packet, NET_PACKET_TYPE_PLAYER_NAME);
    NET_WriteInt8(packet, player);
    NET_WriteString(packet, name);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

static void NET_CL_ParseChatMessage(net_packet_t *packet) {
    unsigned int player;
    char *msg;
    extern void D_HandleChatMessage(int player, const char *msg);
    if (!NET_ReadInt8(packet, &player)) return;
    msg = NET_ReadString(packet);
    if (msg == NULL) return;
    D_HandleChatMessage((int)player, msg);
}

static void NET_CL_ParsePlayerName(net_packet_t *packet) {
    unsigned int player;
    char *name;
    extern void D_HandlePlayerName(int player, const char *name);
    if (!NET_ReadInt8(packet, &player)) return;
    name = NET_ReadString(packet);
    if (name == NULL) return;
    D_HandlePlayerName((int)player, name);
}

void NET_CL_SendKillMessage(const char *msg) {
    net_packet_t *packet;
    if (client_state != CLIENT_STATE_IN_GAME) return;
    packet = NET_NewPacket(4 + (int)strlen(msg));
    NET_WriteInt16(packet, NET_PACKET_TYPE_KILL_MSG);
    NET_WriteString(packet, msg);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

static void NET_CL_ParseKillMessage(net_packet_t *packet) {
    char *msg;
    extern void D_HandleKillMessage(const char *msg);
    msg = NET_ReadString(packet);
    if (msg == NULL) return;
    D_HandleKillMessage(msg);
}

static void NET_CL_ParseNPCState(net_packet_t *packet) {
    unsigned char buf[4000];
    int len = 0;
    unsigned int byte_val;
    while (NET_ReadInt8(packet, &byte_val) && len < (int)sizeof(buf)) {
        buf[len++] = (unsigned char)byte_val;
    }
    if (len > 0) {
        extern void D_ApplyNPCState(unsigned char *data, int len);
        D_ApplyNPCState(buf, len);
    }
}

static void NET_CL_ParsePlayerJoined(net_packet_t *packet) {
    unsigned int player;
    extern void D_PlayerJoinedMidGame(int player);
    if (!NET_ReadInt8(packet, &player)) return;
    printf("Client: player %d joined mid-game\n", player);
    D_PlayerJoinedMidGame(player);
}

// parse a received packet

static void NET_CL_ParsePacket(net_packet_t *packet)
{
    unsigned int packet_type;

    if (!NET_ReadInt16(packet, &packet_type)) {
        return;
    }

    NET_Log("client: packet from server, type %d", packet_type & ~NET_RELIABLE_PACKET);
    NET_LogPacket(packet);

    if (NET_Conn_Packet(&client_connection, packet, &packet_type)) {
        // Packet eaten by the common connection code
    }
    else {
        switch (packet_type) {
        case NET_PACKET_TYPE_SYN:
            NET_CL_ParseSYN(packet);
            break;

        case NET_PACKET_TYPE_REJECTED:
            NET_CL_ParseReject(packet);
            break;

        case NET_PACKET_TYPE_WAITING_DATA:
            NET_CL_ParseWaitingData(packet);
            break;

        case NET_PACKET_TYPE_LAUNCH:
            NET_CL_ParseLaunch(packet);
            break;

        case NET_PACKET_TYPE_GAMESTART:
            NET_CL_ParseGameStart(packet);
            break;

        case NET_PACKET_TYPE_GAMEDATA:
            NET_CL_ParseGameData(packet);
            break;

        case NET_PACKET_TYPE_GAMEDATA_RESEND:
            NET_CL_ParseResendRequest(packet);
            break;

        case NET_PACKET_TYPE_CONSOLE_MESSAGE:
            NET_CL_ParseConsoleMessage(packet);
            break;

        case NET_PACKET_TYPE_PLAYER_STATE:
            NET_CL_ParsePlayerState(packet);
            break;

        case NET_PACKET_TYPE_HEALTH_AUTH:
            NET_CL_ParseHealthAuth(packet);
            break;

        case NET_PACKET_TYPE_NPC_STATE:
            NET_CL_ParseNPCState(packet);
            break;

        case NET_PACKET_TYPE_WORLD_STATE:
            NET_CL_ParseWorldState(packet);
            break;

        case NET_PACKET_TYPE_CHAT_MSG:
            NET_CL_ParseChatMessage(packet);
            break;

        case NET_PACKET_TYPE_PLAYER_NAME:
            NET_CL_ParsePlayerName(packet);
            break;

        case NET_PACKET_TYPE_KILL_MSG:
            NET_CL_ParseKillMessage(packet);
            break;

        case NET_PACKET_TYPE_PLAYER_JOINED:
            NET_CL_ParsePlayerJoined(packet);
            break;

        case NET_PACKET_TYPE_PONG:
        {
            unsigned int send_ts;
            if (NET_ReadInt32(packet, &send_ts)) {
                int rtt = (int)(I_GetTimeMS() - send_ts);
                if (rtt < 0) rtt = 0;
                if (rtt > 9999) rtt = 9999;
                // Exponential moving average: 70% old + 30% new
                if (ping_rtt == 0)
                    ping_rtt = rtt;
                else
                    ping_rtt = (ping_rtt * 7 + rtt * 3) / 10;
            }
            break;
        }

        default:
            break;
        }
    }
}

// "Run" the client code: check for new packets, send packets as
// needed

void NET_CL_Run(void)
{
    net_addr_t *addr;
    net_packet_t *packet;

    if (!net_client_connected) {
        return;
    }

    while (NET_RecvPacket(client_context, &addr, &packet)) {
        // only accept packets from the server

        if (addr == server_addr) {
            NET_CL_ParsePacket(packet);
        }

        NET_FreePacket(packet);
        NET_ReleaseAddress(addr);
    }

    // Run the common connection code to send any packets as needed

    NET_Conn_Run(&client_connection);

    if (client_connection.state == NET_CONN_STATE_DISCONNECTED ||
        client_connection.state == NET_CONN_STATE_DISCONNECTED_SLEEP) {
        NET_CL_Disconnected();

        NET_CL_Shutdown();
    }

    net_waiting_for_launch =
        client_connection.state == NET_CONN_STATE_CONNECTED && client_state == CLIENT_STATE_WAITING_LAUNCH;

    if (client_state == CLIENT_STATE_IN_GAME) {
        // Possibly advance the receive window

        NET_CL_AdvanceWindow();

        // Check if our resend requests have timed out

        NET_CL_CheckResends();

        // Send periodic PING for RTT measurement
        {
            unsigned int now = I_GetTimeMS();
            if (now - ping_send_time >= PING_INTERVAL_MS) {
                net_packet_t *ping = NET_NewPacket(6);
                NET_WriteInt16(ping, NET_PACKET_TYPE_PING);
                NET_WriteInt32(ping, now);
                NET_Conn_SendPacket(&client_connection, ping);
                NET_FreePacket(ping);
                ping_send_time = now;
            }
        }
    }
}

static void NET_CL_SendSYN(net_connect_data_t *data)
{
    net_packet_t *packet;

    NET_Log("client: sending SYN");

    packet = NET_NewPacket(10);
    NET_WriteInt16(packet, NET_PACKET_TYPE_SYN);
    NET_WriteInt32(packet, NET_MAGIC_NUMBER);
    NET_WriteString(packet, PACKAGE_STRING);
    NET_WriteProtocolList(packet);
    NET_WriteConnectData(packet, data);
    NET_WriteString(packet, net_player_name);
    NET_Conn_SendPacket(&client_connection, packet);
    NET_FreePacket(packet);
}

// Connect to a server

boolean NET_CL_Connect(net_addr_t *addr, net_connect_data_t *data)
{
    int start_time;
    int last_send_time;
    boolean sent_hole_punch;

    server_addr = addr;
    NET_ReferenceAddress(addr);

    memcpy(net_local_wad_sha1sum, data->wad_sha1sum, sizeof(sha1_digest_t));
    memcpy(net_local_deh_sha1sum, data->deh_sha1sum, sizeof(sha1_digest_t));
    net_local_is_freedoom = data->is_freedoom;

    // create a new network I/O context and add just the necessary module
    client_context = NET_NewContext();

    // initialize module for client mode
    if (!addr->module->InitClient()) {
        SetRejectReason("Failed to initialize client module");
        return false;
    }

    NET_AddModule(client_context, addr->module);

    net_client_connected = true;
    net_client_received_wait_data = false;
    sent_hole_punch = false;

    NET_Conn_InitClient(&client_connection, addr, NET_PROTOCOL_UNKNOWN);

    // try to connect
    start_time = I_GetTimeMS();
    last_send_time = -1;
    SetRejectReason("Unknown reason");

    while (client_connection.state == NET_CONN_STATE_CONNECTING) {
        int nowtime = I_GetTimeMS();

        // Send a SYN packet every second.
        if (nowtime - last_send_time > 1000 || last_send_time < 0) {
            NET_CL_SendSYN(data);
            last_send_time = nowtime;
        }

        // time out after 120 seconds
        if (nowtime - start_time > 120000) {
            SetRejectReason("No response from server");
            break;
        }

        // run client code
        // printf("net_client.c :: NET_CL_Run()\n");
        NET_CL_Run();

        // run the server, just in case we are doing a loopback connect
        // printf("net_client.c :: NET_SV_Run()\n");
        NET_SV_Run();

        // Don't hog the CPU
        I_Sleep(1);
    }

    if (client_connection.state == NET_CONN_STATE_CONNECTED) {
        // connected ok!
        NET_Log("client: connected successfully");
        SetRejectReason(NULL);
        client_state = CLIENT_STATE_WAITING_LAUNCH;
        drone = data->drone;

        return true;
    }
    else {
        // failed to connect
        NET_Log("client: failed to connect");
        NET_CL_Shutdown();

        return false;
    }
}

// read game settings received from server

boolean NET_CL_GetSettings(net_gamesettings_t *_settings)
{
    if (client_state != CLIENT_STATE_IN_GAME) {
        return false;
    }

    memcpy(_settings, &settings, sizeof(net_gamesettings_t));

    return true;
}

// disconnect from the server

void NET_CL_Disconnect(void)
{
    int start_time;

    if (!net_client_connected) {
        return;
    }

    NET_Log("client: beginning disconnect");
    NET_Conn_Disconnect(&client_connection);

    start_time = I_GetTimeMS();

    while (client_connection.state != NET_CONN_STATE_DISCONNECTED &&
           client_connection.state != NET_CONN_STATE_DISCONNECTED_SLEEP) {
        if (I_GetTimeMS() - start_time > 5000) {
            // time out after 5 seconds

            NET_Log("client: no acknowledgement of disconnect received");
            client_state = CLIENT_STATE_WAITING_START;

            fprintf(stderr, "NET_CL_Disconnect: Timeout while disconnecting "
                            "from server\n");
            break;
        }

        NET_CL_Run();
        NET_SV_Run();

        I_Sleep(1);
    }

    // Finished sending disconnect packets, etc.
    NET_Log("client: disconnect complete");
    NET_CL_Shutdown();
}

void NET_CL_Init(void)
{
    // Try to set from the USER and USERNAME environment variables
    // Otherwise, fallback to "Player"

    if (net_player_name == NULL) {
        int i = M_CheckParmWithArgs("-pet", 1);
        if (i > 0) {
            net_player_name = myargv[i + 1];
        }
        else {

            net_player_name = NET_GetRandomPetName();
        }
    }
}

void NET_Init(void)
{
    NET_OpenLog();
    NET_CL_Init();
}

void NET_BindVariables(void) { M_BindStringVariable("player_name", &net_player_name); }
